package arg.centro8.curso.java.estudio.enums;

public enum Hora {
    Turno_9_00,
    Turno_9_30,
    Turno_10_00,
    Turno_10_30,
    Turno_11_00,
    Turno_11_30,
    Turno_12_00,
    Turno_12_30,
    Turno_13_00,
    Turno_13_30,
    Turno_14_00
}
