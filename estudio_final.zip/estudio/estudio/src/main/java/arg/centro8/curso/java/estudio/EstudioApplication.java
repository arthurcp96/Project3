package arg.centro8.curso.java.estudio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstudioApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstudioApplication.class, args);
	}

}
