package arg.centro8.curso.java.estudio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudioApplicationTests {

	@Test
	void contextLoads() {
	}

}
